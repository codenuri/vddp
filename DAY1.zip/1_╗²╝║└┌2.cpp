#include <iostream>

class Base
{
public:
	Base(int a){ }
	~Base()    { }
};
class Derived : public Base
{
public:						
	Derived()		{ }
	Derived(int a)	{ }
	~Derived()		{ }
};
int main()
{

}
