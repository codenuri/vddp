﻿class Animal
{
public:
	Animal() {}
};
class Dog : public Animal
{
public:
	Dog() {}
};
int main()
{
	// 다음중 에러를 모두 골라 보세요
	Animal a;
	Dog    d;
}



