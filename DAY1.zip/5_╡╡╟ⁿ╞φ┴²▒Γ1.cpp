﻿#include <iostream>
#include <vector>


int main()
{

}

