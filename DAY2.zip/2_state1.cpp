// 1_State1 - 182 page
#include <iostream>

class Character
{
	int gold;
	int color;
public:
	void run()    { std::cout << "run" << std::endl; }
	void attack() { std::cout << "attack" << std::endl; }

	void acquire_item() 
	{
		// ??
	}
};
int main()
{
	Character c;
	c.run();
	c.attack();


	c.acquire_item();
	c.run();
	c.attack();
}



