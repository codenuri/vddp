#include <iostream>

struct Stream
{
	virtual void write(const std::string&) = 0;
	virtual ~Stream() {}
};


class FileStream : public Stream
{
	FILE* file;
public:
	FileStream(const char* s, const char* mode = "wt")
	{
		file = fopen(s, mode);
	}
	~FileStream() { fclose(file); }

	void write(const std::string& s) 
	{
		printf("%s 쓰기\n", s.c_str() );
	}
};

int main()
{
	// File 에 쓸때 암호화 해서 쓰는 기능이 필요 합니다.
	// 최선의 디지인을 생각해 봅시다.

	FileStream fs("a.txt");
	fs.write("hello");
}
