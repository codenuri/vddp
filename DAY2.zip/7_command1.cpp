#include "monitor.h"

int main()
{
	Monitor m;
	m.info();

	m.set_brightness(90);
	m.info();	
}